class Main{
    public static void main(String args[]){
        System.out.print("Enter structure : ");
        String structure = Validation.checkInputString();
        System.out.print("Enter name : ");
        String name = Validation.checkInputString();
        System.out.print("Enter weight : ");
        float weight = Validation.checkInputFloat();
        
        Molecule mole = new Molecule(structure, name, weight);
        
        mole.display();
        
    }
}