import java.util.Scanner;
class Main{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        String a = sc.nextLine();
        String b = sc.nextLine();
        
        //Cach 1:
        System.out.println(a.concat(" " + b));
        
        //Cach 2:
        // System.out.println(a + b);
    }
}