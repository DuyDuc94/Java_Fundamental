import java.util.Scanner;
public class Validation{
    private static final Scanner sc = new Scanner(System.in);
    
    //check user input string
    public static String checkInputString(){
        String result;
        while(true){
            result = sc.nextLine();
            if(!result.isEmpty()) return result;
            else{
                System.out.println("Can not be empty");
                System.out.println("Stop");
            }
        }
    }
    
    public static float checkInputFloat(){
        float result;
        while(true){
            result = sc.nextFloat();
            if(result>0) return result;
            else{
                System.out.println("a positive, less than 0.01 floating point value ");
                System.out.println("Stop");
            }
        }
    }
}