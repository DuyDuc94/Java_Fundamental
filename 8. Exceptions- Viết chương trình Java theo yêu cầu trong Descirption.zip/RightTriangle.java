public class RightTriangle{
    private int a,b,c;
    public RightTriangle(int a, int b, int c) throws IllegalTriangleException, IllegalRightTriangleException{
        if( a+b<c || b+c<a || c+a<b ) throw new IllegalTriangleException();
        else if( (a*a+b*b)==c*c || (b*b+c*c)==a*a || (c*c+a*a)==b*b ){}
        else throw new IllegalRightTriangleException();
    }
}