import java.util.*;
class Main{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        String in1 = sc.nextLine();
        String in2 = sc.nextLine();
        
        char inArr1[] = in1.toCharArray();
        char inArr2[] = in2.toCharArray(); 
        
        Arrays.sort(inArr1);
        Arrays.sort(inArr2);
        
        boolean check = true;
        
        for(int i=0; i<in1.length(); i++){
            if(inArr1[i] != inArr2[i]){
                check = false;
                break;
            }
        }
        
        System.out.println(check);
    }
}