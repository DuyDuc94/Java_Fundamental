import java.util.Scanner;

public class Validation{
    private static final Scanner sc = new Scanner(System.in);
    
    public static String checkInputString(){
        String result;
        while(true){
            result = sc.nextLine();
            if(!result.isEmpty()) return result;
            else{
                System.err.println("Can Not empty");
                System.out.println("Stop");
            }
        }
    }
    
    public static int checkInputInt(){
        int result;
        while(true){
            result = sc.nextInt(); sc.nextLine();
            if(result >=0) return result;
            else{
                System.err.println("a positive value ");
                System.out.print("Stop");
            }
        }
    }
    
    public static float checkInputFloat(){
        float result;
        while(true){
            result = sc.nextFloat(); sc.nextLine();
            if(result >=0) return result;
            else{
                System.err.println("a positive value ");
                System.out.print("Stop");
            }
        }
    }
    
    public static boolean accept(){
        String result = Validation.checkInputString();
        while(true){
            if(result.equalsIgnoreCase("Y")) return true;
            else if(result.equalsIgnoreCase("N")) return false;
            else{
                System.err.println("Please input y/Y or n/N.");
                System.out.print("Stop"); 
            }
        }
    }
}