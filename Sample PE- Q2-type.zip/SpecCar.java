public class SpecCar extends Car{
    private int type;
    public SpecCar(){}
    public SpecCar(String maker, int price, int type){
        // super.setMaker(maker);
        // super.setPrice(price);
        super(maker, price);
        this.type = type;
    }
    
    public String toString(){
        return super.getMaker() + ", " + super.getPrice() + ", " + type;
    }
    
    public void setData(){
        super.setMaker("XZ" + super.getMaker());
        super.setPrice(super.getPrice() +20);
    }
    
    public int getValue(){
        if(type<7) return super.getPrice() +10;
        else return super.getPrice() +15;
    }
}