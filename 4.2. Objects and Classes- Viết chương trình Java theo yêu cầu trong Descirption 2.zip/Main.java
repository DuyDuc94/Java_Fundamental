class Main{
    static Atoms[] atomArr = new Atoms[20];
    public static void enterData(){
        int i =0;
        // for( i =0; i<20;i++){
            // System.out.println("Enter number: ");
            int number = Validation.checkInputInt();
            // System.out.println("Enter symbol:");
            String symbol = Validation.checkInputString();
            // System.out.println("Enter fullname: ");
            String fullname = Validation.checkInputString();
            // System.out.println("Enter weight: ");
            float weight = Validation.checkInputFloat();
            atomArr[i] = new Atoms(number, symbol, fullname, weight);
        // }
    }
    
    public static void main(String args[]){
        enterData();
        int i =0;
        // for( i =0; i< atomArr.length; i++){
            atomArr[i].display();
        // }
        
        System.out.println();
    }
}