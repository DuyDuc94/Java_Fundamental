public class IllegalTriangleException extends Exception{
    public void duy(){}
}