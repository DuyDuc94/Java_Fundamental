public class Atoms{
    private int number;
    private String symbol;
    private String fullname;
    private float weight;
    
    public Atoms(){}
    public Atoms(int number, String symbol, String fullname, float weight){
        this.number = number;
        this.symbol = symbol;
        this.fullname = fullname;
        this.weight = weight;
    }
    
    public void display(){
        System.out.printf("%-9d%-9s%-9s%-9.3f", number, symbol, fullname, weight);
    }
}