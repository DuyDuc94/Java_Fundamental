import java.util.*;
class Main{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        
        String name = sc.nextLine();
        String words[] = name.split("\\s");
        System.out.print("My initial is ");
        for( String x : words){
            System.out.print(x.charAt(0));
        }
    }
}