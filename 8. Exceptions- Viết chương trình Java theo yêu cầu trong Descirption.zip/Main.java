import java.util.Scanner;

class Main{
    public static final Scanner sc = new Scanner(System.in);
    
    public static int inValid(){
        int result;
        while(true){
            result = sc.nextInt();
            if(result > 0) return result;
            else System.out.println("Not a positive number!");
        }
    }
    
    public static void main(String args[]){
        int a, b, c;
        a = inValid();
        b = inValid();
        c = inValid();
        try{
            RightTriangle triAngle1 = new RightTriangle(a, b, c);
            System.out.println("This is a right triangle!");
        }catch(IllegalTriangleException e1){
            System.out.println("This is not a triangle!");
        }catch(IllegalRightTriangleException e2){
            System.out.println("This is not a right triangle");
        }
    }
}