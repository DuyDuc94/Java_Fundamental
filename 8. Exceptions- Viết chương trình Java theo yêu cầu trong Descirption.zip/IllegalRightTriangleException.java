public class IllegalRightTriangleException extends Exception{
    public void duy(){}
}